// Includes
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <MQTTClient.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>

// Defines
#define MQTT_ADDRESS "tcp://localhost:1883" // Endereço do broker
#define PORT 1883                           // Porta da conexao

#define USER_CONTROL_TOPIC "UCONTROL/%d"  // Nome do tópico de controle do usuário
#define MY_USER_STATUS_TOPIC "USER/%d"    // Nome do tópico de status do meu usuário
#define ALL_USER_STATUS_TOPIC "USER/+"    // Nome do tópico de status de todos os usuários
#define REQ_CHAT "CHAT/%d"                // Solicitação de bate-papo
#define SESSION_TOPIC "SESSION/%d_%d_%lu" // Nome da sessão de conversa (ID do usuário que iniciou a conversa, ID do destinatário e timestamp)
#define STATUS_OFF "0"                    // Status para usuário offline
#define STATUS_ON "1"                     // Status para usuário online

#define GROUP_CONTROL_TOPIC "GCONTROL/%d" // Nome do tópico de controle do lider do grupo
#define MY_GROUP_TOPIC "GROUP/%s"         // Nome do meu tópico de grupo
#define GROUP_TOPIC "GROUP/+"             // Nome do tópico de status de todos os grupos
#define B_GROUP_TOPIC "GROUP/%s/BOSS"     // Nome do tópico de grupo com o nome do lider
#define M_GROUP_TOPIC "GROUP/%s/MEMBER"   // Nome do tópico de grupo com os membros
#define CHAT_GROUP_TOPIC "GROUP/%s/CHAT"  // Nome do tópico de chat do grupo

#define DEFAULT_SIZE 14 // Tamanho máximo padrão do nome de tópicos
#define SESSION_SIZE 20 // Tamanho do nome do tópico de sessão

#define QOS 1                 // Nível de QoS
#define TIMEOUT 1000L         // Tempo de espera em milissegundos
#define RETAINED_STATUS_ON 1  // Status para a mensagem ser retida
#define RETAINED_STATUS_OFF 0 // Status para a mensagem não ser retida

// Variaveis globais
pthread_t threads[1];
MQTTClient client;                 // Cliente do broker
MQTTClient_willOptions will;       // Configurações do serviço last will
int *myUserId;                     // Identificador do usuário
char myControlTopic[DEFAULT_SIZE]; // Nome do tópico de controle do usuário
char userTopic[DEFAULT_SIZE];      // Nome do tópico de usuários
int groupExist = 0;

int finished = 1;

int countGroup = 0;
char groupTopicNames[20][20];

char boss[10];

// Mutex
pthread_mutex_t requestMutex = PTHREAD_MUTEX_INITIALIZER;

// Sumario de funcoes

void publish(MQTTClient client, char *topicName, char *textMsg, int retained);
int on_message(void *context, char *topicName, int topicLen, MQTTClient_message *message);
void *menu();
void createMenu();

// Finaliza e sai do programa
void finish(char *s)
{
    // Atualiza seu status para offline no tópico de usuários
    publish(client, userTopic, STATUS_OFF, RETAINED_STATUS_ON);

    MQTTClient_unsubscribe(client, userTopic);
    MQTTClient_disconnect(client, TIMEOUT);
    perror(s);

    finished = 0;

    exit(1);
}

// Função que publica as mensagens a um tópico específico
void publish(MQTTClient client, char *topicName, char *textMsg, int retained)
{
    MQTTClient_message pubmsg = MQTTClient_message_initializer;

    pubmsg.payload = textMsg;
    pubmsg.payloadlen = strlen(pubmsg.payload);
    pubmsg.qos = QOS;
    pubmsg.retained = retained;
    MQTTClient_deliveryToken token;
    MQTTClient_publishMessage(client, topicName, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, TIMEOUT);
}

// Funcao acionada quando alguma é enviada do broker ao cliente
int onMessage(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int opt = 0;
    char *payload = message->payload;

    char msgTopicName[100];
    strcpy(msgTopicName, topicName);

    if (strstr(msgTopicName, "USER"))
        opt = 1;

    else if (strstr(msgTopicName, "UCONTROL"))
        opt = 2;

    else if (strstr(msgTopicName, "GCONTROL"))
        opt = 7;

    else if (strstr(msgTopicName, "BOSS"))
        opt = 5;

    else if (strstr(msgTopicName, "MEMBER"))
        opt = 6;

    else if (strstr(msgTopicName, "GROUP"))
        opt = 3;
    else
        opt = 4;

    strtok(msgTopicName, "/");

    char *userId = strtok(NULL, " ");

    int targetUserId = atoi(strtok(payload, "CHAT/"));

    char *topicN = strtok(topicName, "/");
    topicN = strtok(NULL, " ");

    // printf("\ntopicName %s topicN %s payload %s msgTopicN %s countG %d", topicName, topicN, payload, msgTopicN, countGroup);

    switch (opt)
    {
    // Lista status dos usuários
    case 1:
        printf("\nUsuario: %s\t", userId);

        if (payload[0] == '1')
            printf("Status: Online\n");
        else
            printf("Status: Offline\n");

        break;

    // Recebe e responde a requisição de bate-papo com outro usuário
    case 2:
        system("clear");

        printf("\nVocê recebeu uma requisição de bate-papo com o usuário [%d].", targetUserId);
        puts("\nResponda com [s] ou [n] para aceitar ou rejeitar a requisição: ");

        pthread_cancel(threads[0]);

        char answer;
        scanf("%s", &answer);

        if (answer == 's')
        {
            printf("\nVoce aceitou a requisicao!, %d %d", targetUserId, *myUserId);

            char targetTopic[DEFAULT_SIZE];
            snprintf(targetTopic, DEFAULT_SIZE, USER_CONTROL_TOPIC, targetUserId);

            char session[SESSION_SIZE];
            snprintf(session, SESSION_SIZE, SESSION_TOPIC, *myUserId, targetUserId, (unsigned long)time(NULL));

            // printf("\ntargetTopic %s session %s targetUserId %d\n", targetTopic, session, targetUserId);

            publish(client, targetTopic, session, RETAINED_STATUS_OFF);
        }

        // puts("\nteste");

        createMenu();

        break;

    // Lista os grupos e suas informações
    case 3:
        groupExist = 1;

        strcpy(groupTopicNames[countGroup], topicN);

        countGroup++;

        break;

    case 4:
        system("clear");
        printf("\nVocê recebeu uma mensagem, topico [%s]: %s", topicName, payload);
        break;

    case 5:
        strcpy(boss, payload);

        // printf("teste\n");

        // pthread_mutex_unlock(&requestMutex);

        break;

    case 6:
        topicN = strtok(topicN, "/MEMBER");

        printf("\nNome do grupo: %s\t\tLíder: %s\tMembros: %s\n", topicN, boss, payload);

        // pthread_mutex_unlock(&requestMutex);
        break;

    default:
        // Imprime a mensagem recebida
        printf("\nUma mensagem foi recebida! \n\rTópico: %s\nMensagem: %s\n", topicName, payload);
        break;
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

// Lista os usuários disponíveis e seus status
void listUsers()
{
    // Assina o tópico de usuários e aguarda o recebimento de mensagens
    MQTTClient_subscribe(client, ALL_USER_STATUS_TOPIC, QOS);
    sleep(1);

    MQTTClient_unsubscribe(client, ALL_USER_STATUS_TOPIC);
}

// Solicita bate-papo com outro usuário
void requestChat()
{
    int targetId;
    printf("Informe o ID de quem você quer iniciar uma conversa: ");
    scanf("%d", &targetId);

    char reqChat[8];
    snprintf(reqChat, 8, REQ_CHAT, *myUserId);

    char targetControlTopic[DEFAULT_SIZE];
    snprintf(targetControlTopic, DEFAULT_SIZE, USER_CONTROL_TOPIC, targetId);

    // printf("%s", targetControlTopic);
    puts("Voce enviou uma solicitação bate-papo!");

    // Publica no tópico do usuário alvo com o tópico da conversa
    publish(client, targetControlTopic, reqChat, RETAINED_STATUS_OFF);
}

// Lista os grupos disponíveis e suas informações
void listGroups()
{
    // Assina o tópico de grupos e aguarda o recebimento de mensagens
    MQTTClient_subscribe(client, GROUP_TOPIC, QOS);
    sleep(3);
    MQTTClient_unsubscribe(client, GROUP_TOPIC);

    for (int i = 0; i < countGroup; i++)
    {
        char bossNameTopic[50];
        snprintf(bossNameTopic, 50, B_GROUP_TOPIC, groupTopicNames[i]);

        // printf("\ncountGroup %d bossNameTopic %s\n", countGroup, bossNameTopic);

        // pthread_mutex_lock(&requestMutex);

        // puts("asds");

        MQTTClient_subscribe(client, bossNameTopic, QOS);
        sleep(1);
        MQTTClient_unsubscribe(client, bossNameTopic);

        // pthread_mutex_lock(&requestMutex);

        char memberNameTopic[50];
        snprintf(memberNameTopic, 50, M_GROUP_TOPIC, groupTopicNames[i]);

        // pthread_mutex_lock(&requestMutex);

        MQTTClient_subscribe(client, memberNameTopic, QOS);
        sleep(1);
        MQTTClient_unsubscribe(client, memberNameTopic);
    }

    countGroup = 0;
}

// Cria um novo grupo, mas caso o mesmo já exista, solicita entrada
void createGroup()
{
    char groupN[20];
    printf("Informe o nome do grupo a ser criado: ");
    scanf("%s", groupN);

    char topicName[30];
    snprintf(topicName, 30, MY_GROUP_TOPIC, groupN);

    // printf("topicName %s\n", topicName);

    // Assina o tópico de grupos e aguarda o recebimento de mensagens
    MQTTClient_subscribe(client, topicName, QOS);

    sleep(2);

    MQTTClient_unsubscribe(client, topicName);

    char msg2[100];
    sprintf(msg2, "%d", *myUserId);

    if (!groupExist)
    {
        char bossTopicName[50];
        snprintf(bossTopicName, 50, B_GROUP_TOPIC, groupN);
        publish(client, bossTopicName, msg2, RETAINED_STATUS_ON);

        char memberTopicName[50];
        snprintf(memberTopicName, 50, M_GROUP_TOPIC, groupN);
        publish(client, memberTopicName, "-", RETAINED_STATUS_ON);

        printf("Grupo foi criado!\n");
    }
    else
    {
        printf("\nEsse grupo já existe, o líder irá lhe adicionar nos membros!\n");
    }
}

// Menu com as opções do sistema
void *menu()
{
    int opt;

    while (1)
    {
        do
        {
            printf("\n\tVocê é o usuário de ID: |%d|\n", *myUserId);
            puts("\n\t\t\tMENU\n");
            puts("\t(1) Para listar todos os usuários e seus respectivos status;");
            puts("\t(2) Para iniciar uma solicitação de conversa com outro usuário;");
            puts("\t(3) Para listar todos os grupos e suas informações;");
            puts("\t(4) Para criar um novo grupo;");
            puts("\t(0) Para encerrar o programa.\n");
            printf("\tDigite um numero correspondente a uma opcao acima: ");
            scanf("%d", &opt);
            switch (opt)
            {
            case 1:
                system("clear");
                listUsers();
                break;
            case 2:
                system("clear");
                requestChat();
                break;
            case 3:
                system("clear");
                listGroups();
                break;
            case 4:
                system("clear");
                createGroup();
                break;
            case 0:
                system("clear");
                finish("Você saiu do programa!");
                break;
            default:
                system("clear");
                puts("Opcao invalida!");
            }
        } while (opt != 0);
    }
}

void createMenu()
{
    pthread_create(&threads[0], NULL, menu, NULL);
    pthread_join(threads[0], NULL);
}

int main(int argc, char *argv[])
{
    myUserId = malloc(sizeof(int));
    if (argc == 1)
    {
        printf("Olá, por favor informe meu ID: ");
        scanf("%d", myUserId);
    }
    else if (argc == 2)
    {
        *myUserId = atoi(argv[1]);
    }

    // Cria uma instância da estrutura de last will
    snprintf(userTopic, DEFAULT_SIZE, MY_USER_STATUS_TOPIC, *myUserId);
    strcpy(will.struct_id, "MQTW");
    will.topicName = userTopic;
    will.message = "0";
    will.qos = 0;
    will.retained = 1;

    // Cria o nome do tópico de controle do usuário
    snprintf(myControlTopic, DEFAULT_SIZE, USER_CONTROL_TOPIC, *myUserId);

    // Cria um cliente pronto para a conexao com o broker
    MQTTClient_create(&client, MQTT_ADDRESS, myControlTopic, MQTTCLIENT_PERSISTENCE_NONE, NULL);

    // Cria threads especificas para cada tipo de interrupcao por meio da chamada de funções
    MQTTClient_setCallbacks(client, NULL, NULL, onMessage, NULL);

    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    conn_opts.will = &will;

    // Inicializa a conexao com o broker
    int mqttConnect = MQTTClient_connect(client, &conn_opts);

    // Caso o cliente consiga se conectar ao broker o programa continua
    if (mqttConnect == MQTTCLIENT_SUCCESS)
    {
        // Assina o proprio usuário no seu tópico de controle para receber solicitacoes
        MQTTClient_subscribe(client, myControlTopic, QOS);

        // Atualiza seu status para online no tópico de usuários
        publish(client, userTopic, STATUS_ON, RETAINED_STATUS_ON);

        // Criacao da thread de menu do sistema
        createMenu();

        while (finished)
        {
        }
        
        pthread_cancel(threads[0]);

        exit(1);
    }
    else
    {
        printf("\n\rFalha na conexao ao broker MQTT. Erro: %d\n", mqttConnect);
        exit(-1);
    }
}
