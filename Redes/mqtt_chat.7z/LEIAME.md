
### Descrição do projeto

#### Execução do programa

Para executar o algoritmo, primeiro é necessário compilá-lo. Para fazer isso, execute a seguinte linha de comando no terminal no diretório do código:

* `gcc main.c -lpaho-mqtt3c -Wall -lpthread -o chat`

Depois de compilado, execute o programa pelo comando: 

* `./chat userId`, onde `userId` é um número que representa o ID do usuário;


#### Tópicos de controle:

Os tópicos de controle estão formatados da seguinte forma:

* O código `#define USER_CONTROL_TOPIC "UCONTROL/%d"` representa todas as requisições de bate-papo com usuário X (`%d`);

* O código `#define GROUP_CONTROL_TOPIC "GCONTROL/%d"` representa todas as requisições de entrada de grupo para com o usuário líder X (`%d`);

* O código `#define ALL_USER_STATUS_TOPIC "USER/+"` representa os status de todos os usuários já conectados; 

* O código `#define SESSION_TOPIC "SESSION/%d_%d_%lu"` representa a sessão aonde acontece o bate-papo;

* O código `#define B_GROUP_TOPIC "GROUP/%s/BOSS"` representa o nome do tópico de grupo que retorna a identificação do líder;

* O código `#define M_GROUP_TOPIC "GROUP/%s/MEMBER"` representa o nome do tópico de grupo que retorna a identificação dos membros.



#### Threads:

O sistema conta com a thread da função inicial `main` que contempla a criação de uma thread para o menu por meio da função `createMenu` que trará as opções do sistema. Além disso, o algoritmo conta com callbacks por meio da função `MQTTClient_setCallbacks`, onde toda vez que uma mensagem é recebida por um cliente ela é ativada pela função `onMessage`.


#### Funcionamento:

Ao executar o programa será criado a conexão com o *broker* utilizando a funcionalidade de *last will* para caso uma ocorra uma interrupção na conexão do cliente.

Depois o menu do sistema será exibido com as seguintes opções:

* (1) Para listar todos os usuários e seus respectivos status;

Nessa opção listará os status dos usuários que já se conectaram alguma vez no sistema.

* (2) Para iniciar uma solicitação de conversa com outro usuário;

Nessa opção o sistema pedirá digitar o ID do usuário ao qual queira conversar e retornará o nome do tópico da sessão caso ele aceite.

* (3) Para listar todos os grupos e suas informações;

Nessa opção listará todos os grupos com seu nome, o usuário líder e os usuários membros;

* (4) Para criar um novo grupo;

Nessa opção o sistema pedirá para digitar o nome do grupo que queira criar, caso o nome já exista uma requisição de entrará será solicitada.

* (0) Para encerrar o programa.

Nessa opção o sistema será encerrado.

Por enquanto a estrutura do programa está definida dessa forma, mas mudanças ainda precisam ser realizadas.

