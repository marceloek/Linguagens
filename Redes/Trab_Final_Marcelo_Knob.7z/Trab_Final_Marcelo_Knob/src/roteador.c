#include "../header/structs.h" // header com as structs e bibliotecas utilizadas

int *id_roteador, socket_udp, confirmacao = 0, tentativas = 0, num_vizinhos = 0;
int tabela[NODOS][NODOS], meu_vetor_dist[NODOS], saida[NODOS];
pthread_mutex_t mutex_confirmacao = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_tabela = PTHREAD_MUTEX_INITIALIZER;
struct roteador roteadores[NODOS];
struct roteador_vizinho rot_vizinhos[NODOS];
struct sockaddr_in si_me, si_other;

void die(char *s)
{
    perror(s);
    exit(1);
}

void tempo_atual()
{
    struct timeval tv;
    struct timezone tz;
    struct tm *tm;
    gettimeofday(&tv, &tz);
    tm = localtime(&tv.tv_sec);
    printf("%d:%02d:%02d:%d.\n", tm->tm_hour, tm->tm_min, tm->tm_sec, (int)tv.tv_usec);
}

int encontra_id(int id_rot)
{
    for (int i = 0; i < NODOS; i++)
    {
        if (roteadores[i].id == id_rot)
            return i;
    }
}

void mapeia_roteadores_configs()
{
    int rot_id, porta, i = 0;
    char ip[15];
    FILE *roteador_file = fopen("configs/roteador.config", "r");
    if (roteador_file == NULL)
        die("Não foi possível abrir o arquivo 'roteador.config'!");
    while (fscanf(roteador_file, "%d %d %s", &rot_id, &porta, ip) != EOF)
    {
        roteadores[i].id = rot_id;
        roteadores[i].porta = porta;
        strcpy(roteadores[i].ip, ip);
        i++;
    }
    fclose(roteador_file);
}

void mapeia_roteadores_enlaces()
{
    int rot_id1, rot_id2, custo, k = 0;
    FILE *enlaces_file = fopen("configs/enlaces.config", "r");
    if (enlaces_file == NULL)
        die("Não foi possível abrir o arquivo 'enlaces.config'!");
    memset(rot_vizinhos, -1, sizeof(rot_vizinhos));
    while (fscanf(enlaces_file, "%d %d %d", &rot_id1, &rot_id2, &custo) != EOF)
    {
        if (*id_roteador == rot_id1 || *id_roteador == rot_id2)
        {
            if (*id_roteador == rot_id1)
                rot_vizinhos[k].id = rot_id2;
            else
                rot_vizinhos[k].id = rot_id1;
            rot_vizinhos[k].custo = custo;
            k++;
        }
    }
    fclose(enlaces_file);
    num_vizinhos = k;

    memset(meu_vetor_dist, -1, sizeof(meu_vetor_dist));

    // cria o vetor distancia do proprio roteador com base no arquivo de enlances
    if (num_vizinhos != 0)
    {
        for (int i = 0; i < NODOS; i++)
        {
            for (int j = 0; j < num_vizinhos; j++)
            {
                if (roteadores[i].id == rot_vizinhos[j].id)
                {
                    meu_vetor_dist[i] = rot_vizinhos[j].custo;
                    break;
                }
                else if (roteadores[i].id == *id_roteador)
                {
                    meu_vetor_dist[i] = 0;
                    break;
                }
                else
                    meu_vetor_dist[i] = -1;
            }
        }
    }
    // seto -1 para todos os valores da tabela e da saida
    memset(tabela, -1, sizeof(tabela));
    memset(saida, -1, sizeof(saida));

    // insere o meu vetor distancia na tabela e os id na saida
    for (int i = 0; i < NODOS; i++)
    {
        tabela[encontra_id(*id_roteador)][i] = meu_vetor_dist[i];
        if (tabela[encontra_id(*id_roteador)][i] != -1)
            saida[i] = roteadores[i].id;
    }
}

void imprime_enlaces()
{
    puts("\n\t\t  Roteadores vizinhos\n\t\t      ID    Custo");
    puts("\t\t----------------------");
    for (int i = 0; i < num_vizinhos; i++)
    {
        printf("\t\t     |%d|    |%d|\n", rot_vizinhos[i].id, rot_vizinhos[i].custo);
    }
}

void imprime_configs()
{
    puts("\n\t     Configuração dos roteadores\n\t       ID   Porta\tIP");
    puts("\t    -----------------------------");
    for (int i = 0; i < NODOS; i++)
    {
        printf("\t      |%d|  |%d|  |%s|\n", roteadores[i].id, roteadores[i].porta, roteadores[i].ip);
    }
}

void imprime_tabela_roteamento()
{
    int linha1 = 1;
    printf("\n %d ¦ ", *id_roteador);
    for (int i = 0; i < NODOS; i++)
    {
        if (linha1 == 0)
            printf("\n %d ¦ ", roteadores[i].id);
        for (int j = 0; j < NODOS; j++)
        {
            if (i == 0 && linha1 == 1)
            {
                printf("%d | ", roteadores[j].id);
                continue;
            }
            if (tabela[i][j] == -1)
            {
                printf("∞ | ");
                continue;
            }
            printf("%d | ", tabela[i][j]);
        }
        if (linha1 == 1)
        {
            printf("\n----------------------------");
            linha1 = 0;
            i = -1;
        }
    }
    printf("\nSaida: ");
    for (int i = 0; i < NODOS; i++)
        printf("[%d] ", saida[i]);
    puts("");
}

void cria_socket_udp()
{
    if ((socket_udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
        die("socket");
    }

    memset((char *)&si_me, 0, sizeof(si_me));

    int porta = encontra_id(*id_roteador);
    porta = roteadores[porta].porta;
    si_me.sin_family = AF_INET;
    si_me.sin_port = htons(porta);
    si_me.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(socket_udp, (struct sockaddr *)&si_me, sizeof(si_me)) == -1)
    {
        die("bind");
    }
}

void envia_pacote(pacote pacote_msg, int metodo)
{
    int slen = sizeof(si_other), id_prox_rot, ind_prox_rot, ind_destino = encontra_id(pacote_msg.id_destino);

    if (metodo == ROTEA)
    {
        pthread_mutex_lock(&mutex_tabela);
        id_prox_rot = saida[ind_destino];
        pthread_mutex_unlock(&mutex_tabela);
    }
    else if (metodo == VETOR)
        id_prox_rot = pacote_msg.id_destino;

    ind_prox_rot = encontra_id(id_prox_rot);

    if (id_prox_rot == -1)
    {
        tentativas = 3;
        return;
    }

    if (metodo != VETOR)
        printf("\nencaminhando pacote para o roteador: [%d] %s:%d\n", id_prox_rot, roteadores[ind_prox_rot].ip, roteadores[ind_prox_rot].porta);

    int porta = roteadores[ind_prox_rot].porta;
    char ip[15];
    strcpy(ip, roteadores[ind_prox_rot].ip);

    memset((char *)&si_other, 0, sizeof(si_other));

    si_other.sin_family = AF_INET;
    si_other.sin_port = htons(porta);

    if (inet_aton(ip, &si_other.sin_addr) == 0)
    {
        fprintf(stderr, "inet_aton() failed\n");
        exit(1);
    }

    if (sendto(socket_udp, &pacote_msg, sizeof(struct pacote), 0, (struct sockaddr *)&si_other, slen) == -1)
    {
        die("sendto()");
    }
}

void envia_vetor_distancia()
{
    pacote vetor_pac;
    vetor_pac.id_origem = *id_roteador;
    vetor_pac.tipo = CONTROLE;
    vetor_pac.ack = 0;

    for (int i = 0; i < NODOS; i++)
        vetor_pac.vetor_dist[i] = tabela[encontra_id(*id_roteador)][i];

    for (int i = 0; i < num_vizinhos; i++)
    {
        vetor_pac.id_destino = rot_vizinhos[i].id;
        envia_pacote(vetor_pac, VETOR);
    }
}

void atualiza_tabela()
{
    pthread_mutex_lock(&mutex_tabela);
    int indice_rot = encontra_id(*id_roteador), mudou = 0;
    for (int i = 0; i < NODOS; i++)
    {
        if (indice_rot == i) // é a propria posicao do roteador com valor 0
            continue;
        for (int j = 0; j < NODOS; j++)
        {
            if (j == indice_rot || tabela[j][i] == -1 || tabela[j][indice_rot] == -1)
                // j == indice_rot é a própria linha do roteador na tabela;
                // tabela[j][i] verifica se o vizinho tem caminho para o próprio roteador;
                // tabela[j][indice_rot] verifica se o vizinho tem um caminho para tal roteador
                continue;

            int custo_compara = tabela[j][i] + tabela[j][indice_rot];
            if ((tabela[indice_rot][i] == -1) || (tabela[indice_rot][i] > custo_compara))
            {
                tabela[indice_rot][i] = custo_compara;
                saida[i] = saida[encontra_id(roteadores[j].id)];
                mudou = 1;
            }
        }
    }
    pthread_mutex_unlock(&mutex_tabela);
    if (mudou == 1)
    {
        printf("\n\nTabela foi atualizada em: ");
        tempo_atual();
        imprime_tabela_roteamento();
        envia_vetor_distancia();
    }
}

void insere_vetor_vizinho_tabela(int vetor_distancia[NODOS], int linha)
{
    for (int i = 0; i < NODOS; i++)
    {
        tabela[linha][i] = vetor_distancia[i];
    }
}

void *recebe_pacote()
{
    pacote pacote_msg;
    int slen = sizeof(si_other), recv_len;
    char buf[BUFLEN];

    while (1)
    {
        if ((recv_len = recvfrom(socket_udp, &pacote_msg, sizeof(struct pacote), 0, (struct sockaddr *)&si_other, &slen)) == -1)
        {
            die("recvfrom()");
        }

        if (pacote_msg.id_destino != *id_roteador)
        {
            pacote_msg.saltos++;
            if (pacote_msg.tipo == DADOS)
                printf("\nRoteador [%d] repassando pacote mensagem de origem [%d] com destino [%d] com %d salto(s).\n", *id_roteador, pacote_msg.id_origem, pacote_msg.id_destino, pacote_msg.saltos);
            else if (pacote_msg.ack == 1)
                printf("\nRoteador [%d] repassando pacote confirmacao de origem [%d] com destino [%d] com %d salto(s).\n", *id_roteador, pacote_msg.id_origem, pacote_msg.id_destino, pacote_msg.saltos);

            envia_pacote(pacote_msg, ROTEA);
        }
        else if (pacote_msg.id_destino == *id_roteador)
        {
            if (pacote_msg.tipo == DADOS)
            {
                printf("\n\nMensagem recebida de %s:%d em ", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
                tempo_atual();
                printf("Conteúdo da mensagem recebida: %s\n", pacote_msg.msg);

                pacote pacote_confirma;
                pacote_confirma.id_origem = pacote_msg.id_destino;
                pacote_confirma.id_destino = pacote_msg.id_origem;
                strcpy(pacote_confirma.msg, pacote_msg.msg);
                pacote_confirma.ack = 1;
                pacote_confirma.tipo = CONTROLE;
                pacote_confirma.saltos = 0;

                puts("Enviando confirmação do recebimento da mensagem.\n");
                envia_pacote(pacote_confirma, ROTEA);
                sleep(3);
            }
            else if (pacote_msg.ack == 1)
            {
                printf("\nConfirmação de mensagem recebida de %s:%d em ", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
                tempo_atual();
                pthread_mutex_lock(&mutex_confirmacao);
                confirmacao = 1;
                pthread_mutex_unlock(&mutex_confirmacao);
            }
            else if (pacote_msg.tipo == CONTROLE)
            {
                insere_vetor_vizinho_tabela(pacote_msg.vetor_dist, encontra_id(pacote_msg.id_origem));
                sleep(2);
                atualiza_tabela();
            }
        }
    }
}

void envia_mensagem()
{
    int id_destino, verifica = 0, tentativas = 0;
    char msg[BUFLEN];
    struct pacote pacote_msg;
    while (1)
    {
        printf("\nDigite o roteador para o qual a mensagem será enviada: ");
        scanf("%d", &id_destino);
        // verifica destino válido
        for (int i = 0; i < NODOS; i++)
        {
            if (roteadores[i].id == id_destino)
                verifica = 1;
        }
        if (verifica == 1)
            break;
        printf("\nDestino inválido, tente novamente.\n");
    }
    printf("\nDigite o conteúdo da mensagem que sera enviada:\n> ");
    __fpurge(stdin);
    fgets(msg, BUFLEN, stdin);

    pacote_msg.id_origem = *id_roteador;
    pacote_msg.id_destino = id_destino;
    strcpy(pacote_msg.msg, msg);
    pacote_msg.ack = 0;
    pacote_msg.tipo = DADOS;
    pacote_msg.saltos = 0;

    puts("\nEnviando mensagem, por favor, aguarde.");
    envia_pacote(pacote_msg, ROTEA);

    pthread_mutex_lock(&mutex_confirmacao);
    confirmacao = 0;
    pthread_mutex_unlock(&mutex_confirmacao);

    while (1)
    {
        sleep(6);
        pthread_mutex_lock(&mutex_confirmacao);
        if (confirmacao == 0)
        {
            if (tentativas >= 2)
            {
                puts("\nNão foi possível entregar a mensagem!");
                pthread_mutex_unlock(&mutex_confirmacao);
                sleep(3);
                break;
            }
            else
            {
                puts("\nProblema para entregar mensagem. Tentando novamente.");
                tentativas++;
                pthread_mutex_unlock(&mutex_confirmacao);
                envia_pacote(pacote_msg, ROTEA);
            }
        }
        else
        {
            puts("\nMensagem entregue com sucesso.");
            pthread_mutex_unlock(&mutex_confirmacao);
            sleep(3);
            break;
        }
    }
}

void opcoes_vizinhos()
{
    for (int i = 0; i < num_vizinhos; i++)
        printf("(%d) De [%d] para [%d] | custo: [%d]\n", i, *id_roteador, rot_vizinhos[i].id, rot_vizinhos[i].custo);
}

void desliga_enlace()
{
    int opt;

    opcoes_vizinhos();
    printf("\nSelecione o enlace que quer desligar: ");
    scanf("%d", &opt);

    pthread_mutex_lock(&mutex_tabela);
    for (int i = 0; i < NODOS; i++)
    {
        if (saida[i] == rot_vizinhos[opt].id)
            saida[i] = -1;
        tabela[encontra_id(rot_vizinhos[opt].id)][i] = -1;
        tabela[encontra_id(*id_roteador)][i] = -1;
        if (rot_vizinhos[opt].id != roteadores[i].id)
            tabela[encontra_id(*id_roteador)][i] = meu_vetor_dist[i];
    }
    pthread_mutex_unlock(&mutex_tabela);

    rot_vizinhos[opt].id = -1;
    for (int i = 0; i < num_vizinhos; i++)
    {
        if (rot_vizinhos[i].id == -1)
        {
            for (int j = i + 1; j < num_vizinhos; j++)
            {
                if (rot_vizinhos[j].id != -1)
                {
                    rot_vizinhos[i].id = rot_vizinhos[j].id;
                    rot_vizinhos[i].custo = rot_vizinhos[j].custo;
                    rot_vizinhos[j].id = -1;
                }
            }
        }
    }
    num_vizinhos -= 1;
    atualiza_tabela();
}

void atualizar_enlance()
{
    int opt, custo;

    opcoes_vizinhos();
    printf("\nSelecione o enlace que quer atualizar: ");
    scanf("%d", &opt);
    printf("\nDigite o novo custo do enlace: ");
    scanf("%d", &custo);

    pthread_mutex_lock(&mutex_tabela);
    rot_vizinhos[opt].custo = custo;
    meu_vetor_dist[encontra_id(rot_vizinhos[opt].id)] = custo;
    tabela[encontra_id(*id_roteador)][encontra_id(rot_vizinhos[opt].id)] = custo;
    pthread_mutex_unlock(&mutex_tabela);

    envia_vetor_distancia();
}

void *menu()
{
    int opt;
    while (1)
    {
        do
        {
            printf("\n\tEsse é o roteador ID: |%d|\n", *id_roteador);
            puts("\n\t\t\tMENU\n");
            puts("\t(1) Para para enviar uma mensagem ao um roteador;");
            puts("\t(2) Para imprimir os vizinhos;");
            puts("\t(3) Para imprimir os roteadores da rede;");
            puts("\t(4) Para imprimir a tabela de roteamento;");
            puts("\t(5) Para desligar enlace com vizinho;");
            puts("\t(6) Para atualizar enlace com vizinho;");
            puts("\t(0) Para encerrar o programa.\n");
            printf("\tDigite o numero correspondente a opcao: ");
            scanf("%d", &opt);
            switch (opt)
            {
            case 1:
                system("clear");
                envia_mensagem();
                system("clear");
                break;
            case 2:
                system("clear");
                imprime_enlaces();
                break;
            case 3:
                system("clear");
                imprime_configs();
                break;
            case 4:
                system("clear");
                imprime_tabela_roteamento();
                break;
            case 5:
                system("clear");
                desliga_enlace();
                break;
            case 6:
                system("clear");
                atualizar_enlance();
                break;
            case 0:
                system("clear");
                die("Você saiu do programa!");
                break;
            default:
                system("clear");
                puts("Opcao invalida!");
            }
        } while (opt != 0);
    }
}

int main(int argc, char *argv[])
{
    id_roteador = malloc(sizeof(int));
    if (argc == 1)
    {
        die("Identificador do roteador não encontrado ou inválido!");
    }
    *id_roteador = atoi(argv[1]);

    mapeia_roteadores_configs();

    mapeia_roteadores_enlaces();

    cria_socket_udp();

    pthread_t threads[2];

    envia_vetor_distancia();

    pthread_create(&threads[0], NULL, recebe_pacote, NULL);
    pthread_create(&threads[1], NULL, menu, NULL);

    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);

    close(socket_udp);

    return (1);
}