#include <pthread.h>    // threads
#include <stdio.h>      // printf()       
#include <stdio_ext.h>  // __fpurge()
#include <string.h>     // exit(), strcpy()
#include <stdlib.h>     // atoi()
#include <arpa/inet.h>  // inet_aton()
#include <sys/socket.h> // socket()
#include <sys/time.h>   // timer
#include <unistd.h>     // constantes e tipos

#define NODOS 6
#define BUFLEN 100
#define DADOS 1
#define CONTROLE 2
#define ROTEA 1
#define VETOR 2

typedef struct roteador
{
    int id;
    int porta;
    char ip[15];
} roteador;

typedef struct roteador_vizinho
{
    int id;
    int custo;
} roteador_vizinho;

typedef struct pacote
{
    int id_origem;
    int id_destino;
    char msg[100];
    int ack;
    int tipo;
    int saltos;
    int vetor_dist[NODOS];
} pacote;