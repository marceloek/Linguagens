Acadêmico: Marcelo Elias Knob


O CÓDIGO:

No diretório '/bin' contém o arquivo de execução: 'executa', responsável por compilar o código e executar
o programa para cada roteador da rede em um terminal próprio;

No diretório '/configs' contém os arquivos de configuração: 'enlaces.config' e 'roteador.config';

No diretório '/header' contém o arquivo com as structs utilizadas: 'structs.h';

No diretório '/src' contém o arquivo com o código principal: 'roteador.c'.


PARA EXECUTAR:

É necessário executar o arquivo 'executa' localizado no diretório '/bin'. Caso esteja na raíz do 
diretório, basta digitar o seguinte comando para executar o programa:

$ bin/./executa


O PROGRAMA:

Inicialmente é necessário o id do roteador atual, caso não passe esse valor quando executou o programa, 
será impresso um aviso que não foi possível encontrar o identificador e o programa não será executado;

Em seguida, mostrará um menu com as opções que o usuário deseja executar, dentre elas a opção de enviar
mensagem, a qual solicitará que digite o id do roteador para o qual ela será enviada de acordo com 
os roteadores da rede. Depois solicitará que digite a mensagem de até 100 dígitos.

No início da execução do programa, a tabela de roteamento será computada e após algum tempo ela irá 
convergir. Após cada atualização do seu vetor distância, o roteador imprime a tabela com o 
timestamp da mudança. Também é possível verificar a tabela de roteamento pelo menu.

Ao todo, somente 2 threads são utilizadas: uma responsável pelo menu do programa; e outra responsável 
pelo recebimento de pacotes.

As mensagens são roteadas do roteador de origem até o de destino, passando por roteadores intermediários
que irão repassar o pacote para outro roteador até chegar no destino.

Quando uma mensagem é recebida por um roteador será encaminhada uma mensagem de confirmação;

Cada mensagem enviada tem um limite de tempo para o recebimento da confirmação, caso o limite seja
atingido, a mensagem será reenviada.

Cada mensagem tem um limite de 3 tentativas para recebimento de confirmação, caso o limite seja atingido,
a transmissão da mensagem é cancelada.

Para desligar ou atualizar um enlace de algum roteador com seu vizinho, essa opção estará localizada no 
menu, e por meio dela o usuário selecionará o enlace a ser alterado.

