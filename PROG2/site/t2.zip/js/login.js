document.getElementById("form-contato").onsubmit = validaCadastro;

function validaCadastro() {
	var contErro = 0;

	// validação do campo login
	var login = document.getElementById("login");
	var erro_login = document.getElementById("msg-login");
	if (login.value == "") {
		erro_login.innerHTML = "Por favor digite o login";
		erro_login.style.display = 'block';
		contErro += 1;
	}
	else if (login.value.length < 6) {
		erro_login.innerHTML = "O Login deve possuir pelo menos 6 caracteres";
		erro_login.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_login.style.display = 'none';
	}

	// validação do campo senha
	var senha = document.getElementById("senha");
	var erro_senha = document.getElementById("msg-senha");
	if (senha.value == "") {
		erro_senha.innerHTML = "Por favor digite a Senha";
		erro_senha.style.display = 'block';
		contErro += 1;
	}
	else if (senha.value.length < 6) {
		erro_senha.innerHTML = "A Senha deve possuir pelo menos 6 caracteres";
		erro_senha.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_senha.style.display = 'none';
	}
	if (contErro > 0)
		return false;
	else
		alert("Login efetuado com sucesso");
}