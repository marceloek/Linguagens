document.getElementById("form-contato").onsubmit = validaCadastro;

function validaCadastro() {
	var contErro = 0;

	// validação do campo nome
	var nome = document.getElementById("nome");
	var erro_nome = document.getElementById("msg-nome");
	if ((nome.value == "") || (nome.value.indexOf(" ") == -1)) {
		erro_nome.innerHTML = "Por favor digite o Nome completo";
		erro_nome.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_nome.style.display = "none";
	}

	// validação do campo email
	var email = document.getElementById("email");
	var erro_email = document.getElementById("msg-email");
	if ((email.value == "") || (email.value.indexOf("@") == -1)) {
		erro_email.innerHTML = "Por favor digite o E-mail";
		erro_email.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_email.style.display = 'none';
	}
	//validação cpf
	var erro_cpf = document.getElementById("msg-cpf");
	if (valida_cpf(document.getElementById("cpf").value)) {

		erro_cpf.style.display = 'none';
	}
	else {
		erro_cpf.innerHTML = "Por favor digite um cpf valido";
		erro_cpf.style.display = 'block';
		contErro += 1;
	}
	// validação do campo endereco
	var endereco = document.getElementById("endereco");
	var erro_endereco = document.getElementById("msg-endereco");
	if (endereco.value == "") {
		erro_endereco.innerHTML = "Por favor digite o Endereço completo";
		erro_endereco.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_endereco.style.display = "none";
	}

	// validação do campo pet
	var gato = document.getElementById("gato");
	var cachorro = document.getElementById("cachorro");
	var erro_cagat = document.getElementById("msg-cagat");
	if ((cachorro.value == "0") && (gato.value == "0")) {
		erro_cagat.innerHTML = "Por favor selecione ao menos um animal";
		erro_cagat.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_cagat.style.display = 'none';
	}

	// validação do campo login
	var login = document.getElementById("login");
	var erro_login = document.getElementById("msg-login");
	if (login.value == "") {
		erro_login.innerHTML = "Por favor digite o login";
		erro_login.style.display = 'block';
		contErro += 1;
	}
	else if (login.value.length < 6) {
		erro_login.innerHTML = "O Login deve possuir pelo menos 6 caracteres";
		erro_login.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_login.style.display = 'none';
	}

	// validação do campo senha
	var senha = document.getElementById("senha");
	var erro_senha = document.getElementById("msg-senha");
	if (senha.value == "") {
		erro_senha.innerHTML = "Por favor digite a Senha";
		erro_senha.style.display = 'block';
		contErro += 1;
	}
	else if (senha.value.length < 6) {
		erro_senha.innerHTML = "A Senha deve possuir pelo menos 6 caracteres";
		erro_senha.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_senha.style.display = 'none';
	}

	// validação da repetição da senha
	var senha2 = document.getElementById("senha2");
	var erro_senha2 = document.getElementById("msg-senha2");
	if ((senha2.value == "") || (senha.value != senha2.value)) {
		erro_senha2.innerHTML = "A senha não confere";
		erro_senha2.style.display = 'block';
		contErro += 1;
	}
	else {
		erro_senha2.style.display = 'none';
	}

	if (contErro > 0)
		return false;
	else
		alert("Cadastro efetuado com sucesso"); // será removido posteriormente
}
function valida_cpf(cpf) {
	var numeros, digitos, soma, i, resultado, digitos_iguais;
	digitos_iguais = 1;
	if (cpf.length < 11)
		return false;
	for (i = 0; i < cpf.length - 1; i++)
		if (cpf.charAt(i) != cpf.charAt(i + 1)) {
			digitos_iguais = 0;
			break;
		}
	if (!digitos_iguais) {
		numeros = cpf.substring(0, 9);
		digitos = cpf.substring(9);
		soma = 0;
		for (i = 10; i > 1; i--)
			soma += numeros.charAt(10 - i) * i;
		resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
		if (resultado != digitos.charAt(0))
			return false;
		numeros = cpf.substring(0, 10);
		soma = 0;
		for (i = 11; i > 1; i--)
			soma += numeros.charAt(11 - i) * i;
		resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
		if (resultado != digitos.charAt(1))
			return false;
		return true;
	}
	else
		return false;
}