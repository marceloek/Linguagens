DROP DATABASE IF EXISTS petevida;

CREATE DATABASE petevida DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

USE petevida;

DROP USER IF EXISTS 'admpetevida'@'localhost';

CREATE USER 'admpetevida'@'localhost' IDENTIFIED BY '12345679?'; 

GRANT SELECT, INSERT, UPDATE, DELETE ON petevida.* TO 'admpetevida'@'localhost';

create table cliente(
	CPFcli float not null,
	senha varchar(50) not null,
	email varchar(50) not null,
	ender varchar(50) not null,
	telfixo varchar(50) not null,
	constraint pk_cliente primary key(CPFcli)
);
create table animais (
	idani integer auto_increment,
	nome varchar(50) not null,
	CPFcli float not null,
	especie varchar(50) not null,
	raca varchar(50) not null,
	idade integer not null,
	constraint pk_animais primary key(idani,CPFcli),
	constraint fk_anicli foreign key (CPFcli) references cliente(CPFcli)
);
create table espBanhoTosa (
	CPFbanho float not null,
	nome varchar(50) not null,
	email varchar(50) not null,
	salario float not null,
	celular varchar(50) not null,
	constraint pk_espBanhoTosa primary key(CPFbanho)
);
create table atende (
	CPFbanho float not null,
	CPFcli float not null,
	dthora timestamp not null,
	constraint pk_atende primary key(CPFbanho, CPFcli, dthora),
	constraint fk_ateban foreign key(CPFbanho) references espBanhoTosa(CPFbanho),
	constraint fk_atecli foreign key(CPFcli) references cliente(CPFcli)
);
create table veterinario(
	CFMV integer not null,
	CPFvet float not null,
	nome varchar(50) not null,
	salario integer not null,
	email varchar(50) not null,
	celular varchar(50) not null,
	constraint pk_veterinario primary key(CPFvet)
);
create table lote(
	dataChe date not null,
	numLote integer not null,
	fornecedor varchar(50) not null,
	constraint pk_lote primary key(numLote)
);
create table produto(
	idprod integer auto_increment,
	nome varchar(50) not null,
	tipo varchar(50) not null,
	categoria varchar(50) not null,
	preco float not null,
	imagem varchar(50),
	datval date,
	quantidade integer not null,
	numLote integer,
	constraint pk_produto primary key(idprod),
	constraint fk_prolote foreign key (numLote) references lote(numLote)
);
create table consulta(
	CPFvet float not null,
	CPFcli float not null,
	dthora timestamp not null,
	constraint pk_consulta primary key (CPFvet, CPFcli, dthora),
	constraint fk_convet foreign key (CPFvet) references veterinario(CPFvet),
	constraint fk_concli foreign key (CPFcli) references cliente(CPFcli)
);
create table pedidos (
	CPFcli float not null,
	idprod integer not null,
	quantidade integer not null,
	valtotal REAL not null,
	constraint pk_pedido primary key (CPFcli,idprod),
	constraint fk_pedcli foreign key (CPFcli) references cliente(CPFcli),
	constraint fk_pedpro foreign key (idprod) references produto(idprod)
);
insert into lote (dataChe, numLote, fornecedor) values
('2018-10-10', 1010, "Amor de Pets LTDA"),
('2018-02-02', 1002, "Companhia Pet LTDA"),
('2018-09-03', 1009, "Instituto do Pet LTDA"),
('2018-08-08', 1008, "Instituto do Pet LTDA"),
('2018-07-09', 1007, "Companhia Pet LTDA");

insert into produto (nome, tipo, categoria, preco, imagem, datval, quantidade, numLote) values
("Tabletes antipuglas","Comestivel","Cachorro",90,"antipuglas(90,00).jpg",'2021-11-15',20,1002),
("Ração Pedigree","Comestivel","Cachorro",80,"pedigree(80).jpg",'2021-11-15',20,1010),
("Bifinho","Comestivel","Cachorro",15,"bifinho(15,00).jpg",'2021-11-15',20,1010),
("Mascara hidratante","Mascara","Cachorro",35,"mascara(35,00).jpg",'2021-07-28',85,1009),
("Shampoo","Shampoo","Cachorro",8,"shampoo-cao(8).jpg",'2021-09-28',20,1007),
("Shampoo e condicionador","Shampoo","Cachorro",8.99,"shampoo-condi-cao(8.99).jpg",'2021-08-10',20,1008),
("Tapete higiênico","Tapete","Cachorro",58,"tapete-hig(58,00).jpg",'2021-10-18',20,1007),
("Medicamento Antipulgas","Medicamento","Gato",120,"antipulgas(120).jpg",'2021-10-10',42,1010),
("Shampoo Antipulgas","Shampoo","Gato",15,"antipulgas-gatos.png",'2021-12-18',88,1010),
("Shampoo","Shampoo","Gato",7.99,"shampoo-gato.jpg",'2021-12-18',88,1009),
("Ração Golden","Comestivel","Gato",60,"golden.jpg",'2021-12-18',35,1008),
("Ração Premier","Comestivel","Gato",128,"racao(128).jpg",'2021-12-18',25,1002),
("Ração Royal Canin","Comestivel","Gato",210,"racao(210).jpg",'2021-12-18',88,1008),
("Suplemento alimentar","Comestivel","Gato",60,"suplemento(40).jpg",'2021-12-18',130,1007),
("Granulado","Comestivel","Gato",50,"granulado(50).jpg",'2021-12-18',88,1007),
("Ração","Comestivel","Outros",160,"racao(160).jpg",'2021-05-13',45,1002),
("Suplemento","Medicamento","Outros",50,"suplemento(20).jpg",'2021-04-18',102,1009);

insert into produto (nome, tipo, categoria, preco, imagem, quantidade) values
("Brinquedo","Brinquedo","Cachorro",45,"brinq(45,00).jpg",15),
("Brinquedo Corujinha","Brinquedo","Cachorro",32,"brinq-coruj(32,00).jpg",30),
("Brinquedo","Brinquedo","Cachorro",21,"brinquedo(21,00).jpg",45),
("Kit de brinquedos","Brinquedo","Cachorro",23,"kit-brinq(23,00).jpg",27),
("Comedouro","Outros","Cachorro",12,"comed(12,00).jpg",27),
("Brinquedo totem","Brinquedo","Cachorro",30,"totem(30,00).jpg",27),
("Cama","Cama","Cachorro",125,"cama(125).jpg",28),
("Cama","Cama","Cachorro",90,"cama(90,00).jpg",46),
("Coleira","Coleira","Cachorro",70,"coleira(70).jpg",53),
("Coleira","Coleira","Cachorro",80,"coleira(80).jpg",72),
("Coleira","Coleira","Cachorro",90,"coleira(90).jpg",85),
("Coleira antipulgas","Coleira","Cachorro",220,"coleira-antipulgas(220,00).jpg",10),
("Casinha","Casa","Cachorro",990,"casinha(990).jpg",85),
("Coleira","Coleira","Gato",12,"coleira(50).jpg",99),
("Coleira","Coleira","Gato",25,"coleira(25).jpg",31),
("Coleira","Coleira","Gato",15,"coleira(15).jpg",23),
("Casinha","Casa","Gato",160,"casinha(160).jpg",96),
("Casa","Casa","Gato",230,"casa(230).jpg",65),
("Brinquedo","Brinquedo","Gato",94.9,"brinquedo(94.9).jpg",85),
("Brinquedo","Brinquedo","Gato",4,"brinquedo(4).jpg",25),
("Brinquedo","Brinquedo","Gato",40,"brinq(40).jpg",65),
("Kit de brinquedos","Brinquedo","Gato",40,"kit(29).jpg",65),
("Bebedouro","Bebedouro","Gato",200,"bebedouro(200).jpg",32),
("Bandeja","Outros","Gato",130,"bandeja(130).jpg",107),
("Areia","Outros","Gato",35,"areia(35).jpg",85),
("Bebedouro","Bebedouro","Outros",2,"bebedouro(2).jpg",32),
("Gaiola","Gaiola","Outros",60,"gaiola(60).jpg",32),
("Casinha Carlu","Casa","outros",109.90,"casinha_carlu(109.90).jpg",12),
("Brinquedo em madeira para papagaios","Brinquedo","outros",44,"brinque_papagaios(44).jpg",25);

insert into cliente(CPFcli, senha, email, ender, telfixo) values
(12345678123,"teste1","teste1@hotmail.com","rua marechal teodoro", "1122334455"),
(47007314864,"teste2","teste2@hotmail.com","av porto alegre", "1234567891"),
(23435324243,"teste3","teste3@hotmail.com","pouso alegre", "1431352353");

insert into animais(CPFcli, nome, especie, raca, idade) values
(12345678123,"rodolfo", "Gato", "persa", "3"),
(47007314864,"thomas", "Cachorro", "boxer", "6"),
(43435324243,"louro", "Coelho", "Lop","1");

insert into espBanhoTosa(CPFbanho, nome, email, salario, celular) values
(3213141341,"Carlos","esp1@hotmail.com",1500.00,"1231432432"),
(4314253632,"Maria","esp2@hotmail.com",1500.00,"3535534535"),
(7596545667,"João","esp3@hotmail.com",1500.00,"4134134343");

insert into atende(CPFcli,CPFbanho,dthora) values
(12345678123,3213141341,"2018/11/21 15:00"),
(47007314864,4314253632,"2018/11/22 12:00"),	
(43435324243,7596545667,"2018/11/23 13:00");

insert into veterinario(CFMV,CPFvet,nome,salario,email,celular) values
(12345,1243576442,"Murilo",2700.00,"vet1@hotmail.com","1536645646"),
(12333,5378594432,"Pedro",2700.00,"vet2@hotmail.com","1242352423"),
(45555,5138364674,"Beatriz",2700.00,"vet3@hotmail.com","7945356534");

insert into consulta(CPFvet, CPFcli, dthora) values
(1243576442,12345678123,"2018/12/10 10:00"),
(5378594432,47007314864,"2018/12/10 15:00"),
(5138364674,43435324243,"2018/12/10 15:00");

insert into pedidos(CPFcli,quantidade,valtotal,idprod) values
(12345678123,2,180.00,1),
(47007314864,1,80.00,2),
(43435324243,3,45.00,3);


