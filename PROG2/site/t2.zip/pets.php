<?php
include "includes/cabecalho.php";

$categoria = isset($_GET['categoria']) ? $_GET['categoria'] : false;
$busca = isset($_GET['busca']) ? $_GET['busca'] : '';
$title = array(
	'cachorro' => 'cachorros',
	'gato' => 'gatos',
	'outros' => 'os demais animais'
);

$tipos = array(
	'Coleira' => array(
		'nome' => 'Coleiras',
		'qnt' => 0
	),
	'Comestivel' => array(
		'nome' => 'Comestíveis',
		'qnt' => 0
	),
	'Shampoo' => array(
		'nome' => 'Shampoos',
		'qnt' => 0
	),
	'Cama' => array(
		'nome' => 'Camas',
		'qnt' => 0
	),
	'Casa' => array(
		'nome' => 'Casas',
		'qnt' => 0
	),
	'Brinquedo' => array(
		'nome' => 'Brinquedos',
		'qnt' => 0
	),
	'Tapete' => array(
		'nome' => 'Tapetes',
		'qnt' => 0
	),
	'Mascara' => array(
		'nome' => 'Mascaras',
		'qnt' => 0
	),
	'Bebedouro' => array(
		'nome' => 'Bebedouros',
		'qnt' => 0
	),
	'Medicamento' => array(
		'nome' => 'Medicamentos',
		'qnt' => 0
	),
	'Gaiola' => array(
		'nome' => 'Gaiolas',
		'qnt' => 0
	),
	'Outros' => array(
		'nome' => 'Outros',
		'qnt' => 0
	),
);

include "includes/conexao.php";

// $sql = "SELECT tipo, count(tipo) as count FROM `produto` WHERE categoria = '$categoria' group by tipo";
// $resultado = mysqli_query($conexao, $sql);

$where = 'categoria = ?';
$param = $categoria;

if (!$categoria) {
	$where = 'nome LIKE ?';
	$param = '%'.$busca.'%';
}

$statement = $conexao->prepare("SELECT tipo, count(tipo) as count FROM `produto` WHERE $where group by tipo");
// "i" significa um parametro do tipo inteiro
// "s" significa um parametro do tipo string
// "d" significa um parametro do tipo double
$statement->bind_param("s", $param);
$statement->execute();
$result = $statement->get_result();

// while ($value = mysqli_fetch_array($resultado)){
while ($value = $result->fetch_assoc()) {
	$tipos[$value['tipo']]['qnt'] = $value['count'];
}

// $sql = "SELECT * FROM `produto` WHERE categoria = '$categoria'";
// $produtos = mysqli_query($conexao, $sql);

$statement = $conexao->prepare("SELECT * FROM `produto` WHERE ".$where);
// "i" significa um parametro do tipo inteiro
// "s" significa um parametro do tipo string
// "d" significa um parametro do tipo double
$statement->bind_param("s", $param);
$statement->execute();
$produtos = $statement->get_result();

include "includes/functions.php";

?>
	<main>
		<aside class="col-11">
			<h4>A contagem de itens para cada tipo:</h4>
			<ul>
				<?php foreach ($tipos as $value) { ?>
				<li><?php echo $value['nome']; ?> (<?php echo $value['qnt']; ?>);</li>
				<?php 
		} ?>
			</ul>
		</aside>
		<section class="col-12">
		
			<?php if ($categoria) { ?>
			<h2 id="h2p">Produtos para <?php echo isset($title[$categoria]) ? $title[$categoria] : $categoria; ?></h2>
			<?php } else { ?>
			<h2 id="h2p">Resultado da busca por "<?php echo $busca; ?>"</h2>
			<?php } ?>
			
			<div class="lista-produtos">
				<?php while ($value = $produtos->fetch_assoc()) { ?>
				
				<div class="produto">
					<a href="#">
						<figure>
							<img src="img/products/<?= $value['categoria']; ?>/<?= mostraImagem($value['imagem']); ?>" alt="<?= $value['imagem']; ?>">
							<figcaption>
								<?= mostraImagem($value['nome']) ?>
								<span class="preco"><?= mostraPreco($value['preco']) ?></span>
							</figcaption>
						</figure>
					</a>
				</div>
				
				<?php 
		} ?>
			</div>
		</section>
	</main>

<?php
include "includes/rodape.php";
?>