<!doctype html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="description" content="Aqui você pode tratar seu bicho de estimação e encontra produtos para seu animal.">
	<meta name="keywords" content="pet, petshop, pet shop, animal, bicho, estimação">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Pet é vida - Melhor lugar para cuidar do seu querido bichinho de estimação</title>
	<link href="img/index-icons/logo.png" rel="shortcut icon" type="image/x-png">
	<link href="https://fonts.googleapis.com/css?family=Scada|Federant" rel="stylesheet">
	<link href="css/index.css" rel="stylesheet" type="text/css">
</head>
<body>
	<header>
		<section class="col-1">
			<table>
				<tr>
					<td>
						<a href="index.php"><img id="logo" src="img/index-icons/logo.png" alt="logo"></a>
					</td>
					<td>
						<h1><a id="titleh1" href="index.php">Pet é vida</a></h1>
					</td>
				</tr>
			</table>
		</section>
		<div class="col-2">
			<nav class="figuras">
				<div class="icons">
					<a href="pets.php?categoria=cachorro">
						<figure>
							<img src="img/index-icons/dog-bone.png" alt="Cães">
							<figcaption>Cães</figcaption>
						</figure>
					</a>
				</div>
				<div class="icons">
					<a href="pets.php?categoria=gato">
						<figure>
							<img src="img/index-icons/cat.png" alt="Gatos">
							<figcaption>Gatos</figcaption>
						</figure>
					</a>
				</div>
				<div class="icons">
					<a href="pets.php?categoria=outros">
						<figure>
							<img src="img/index-icons/cage.png" alt="Demais Pets">
							<figcaption>Demais Pets</figcaption>
						</figure>
					</a>
				</div>
				<div class="icons">
					<a href="about.php">
						<figure>
							<img src="img/index-icons/about.png" alt="Sobre nós">
							<figcaption>Sobre nós</figcaption>
						</figure>
					</a>
				</div>
			</nav>
		</div>
		<hr>
		<div class="col-3">
			<a href="cliente.php">Faça seu login. </a>
			<a href="cliente.php">Cadastre-se.</a>
		</div>
		<div class="col-4">
			<form action="pets.php">
				<input type="search" placeholder="O que você procura?" name="busca" value="<?= isset($_GET['busca']) ? $_GET['busca'] : ''; ?>">
				<button id="buscar">BUSCAR</button>
			</form>
		</div>
	</header>
	<hr>