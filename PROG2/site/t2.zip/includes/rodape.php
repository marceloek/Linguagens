	<footer>
		<p>Todos os direitos reservados. Pet é vida - Chapecó-SC. 2018.</p>
		<ul class="social">
			<li><a href="http://facebook.com/petevida"><img class="img" src="img/index-icons/fb.jpg" alt="Facebook"></a></li>
			<li><a href="http://twitter.com/petevida"><img class="img" src="img/index-icons/twitter.png" alt="Twitter"></a></li>
			<li><a href="http://plus.google.com/petevida"><img class="img" src="img/index-icons/google+.png" alt="Google+"></a></li>
		</ul>
	</footer>
</body>
</html>