<?php
include "includes/cabecalho.php";
?>
<main>
    <div class="col-13">
        <h2 id="h2">Quem somos</h2>
        <h3>Sobre o que é o site?</h3>
        <p>Esse site tem como objetivo a recriação de uma empresa com o tema de um pet
            shop. Seu contéudo é exclusivamente dedicado para aprendizado acadêmico e todos os produtos aqui inseridos são fictícios e meramente
            ilustrações. Além
            disso, um wireframe foi previamente contruído para a criação desse site. Todos o site foi desenvolvido por
            dois
            alunos, Marcelo Knob e Philipe Soares, ambos acadêmicos da Universidade Federal da Fronteira Sul e
            cursantes do
            bacharelado de Ciência da Computação. Somente foi possível sua construção por meio das aulas de Programação
            II,
            onde foi possível aprender um pouco das linguagens como HTML, CSS, JavaScript e PHP.</p>
        <h3>Como ele funciona?</h3>
        <p>Funciona por meio de cadastro de clientes e os usuários podem ser, além de clientes, funcionários da empresa. No site é possível tanto comprar mercadorias para os pets como marcar consultas para os mesmos.</p>
        <h3>O que vendemos?</h3>
        <p>A empresa vende utensílios preferencialmente para gatos e cachorros com uma variedade que inclui rações, medicamentos, shampoos,
            brinquedos e outros.</p>
        <h3>Onde estamos localizados?</h3>
        <p>A loja é meramente ilustrativa, ou seja, não existe um estabelecimento fixo.</p>
        <details>
            <summary>
                Ver endereço:
            </summary>
            <p>02, SC-484 - Fronteira Sul, Chapecó - SC, 89815-899</p>
        </details>
        <br><br>
        <div class="col-20">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14204.18257333222!2d-52.722257830224606!3d-27.123372299999986!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1spt-BR!2sbr!4v1534185687754"></iframe>
        </div>
    </div>
</main>
<?php
include "includes/rodape.php";
?>