<?php
include "includes/cabecalho.php";
?>
	<main>
        <?php 
        include "includes/conexao.php";
		include "includes/functions.php";

        if (isset($_GET['busca'])) {
            $titulo = "Resultado da busca por \"{$_GET['busca']}\" ";
        } else {
            $titulo = "Alguns produtos";
        } ?>

		<section class="col-5">
            <h2 id="h2m">Mais requisitados</h2>
			<?php
			$sql = "select idprod, count(*) as ocorrencias from pedidos group by idprod order by ocorrencias desc limit 3"; 	// busca os 3 mais pedidos
			$resultado = mysqli_query($conexao, $sql);
			while($lista = mysqli_fetch_array($resultado)){	
				$sql = "select idprod, nome, imagem, preco from produto where id = {$lista['idProduto']}";
				$res = mysqli_query($conexao, $sql);
				$produto = mysqli_fetch_array($res);	
			?>

			<div class="requis">
				<div class="prequis">
					<a href="#">
						<figure>
							<img src="img/products/<?= $value['categoria']; ?>/<?= mostraImagem($value['imagem']); ?>" alt="<?= $value['imagem']; ?>">
							<figcaption> 
								<?= $value['nome']; ?>
								<span class="preco">
									<?= mostraPreco($value['preco']) ?>
								</span>
							</figcaption>
						</figure>
					</a>
				</div>
				<?php
			}
			?>
			</div>
        </section>

		<section class="col-6">
			<h2 id="h2p"><?= $titulo ?></h2>
			<div class="lista-produtos">

			<?php 
			$sql = "select idprod, nome, imagem, preco, categoria from produto";
			if(isset($_GET['busca']))
				$sql.=" where nome like '%{$_GET['busca']}%'";
			else
				$sql.= " order by idprod desc limit 12";

			$resultado = mysqli_query($conexao, $sql);
			if(mysqli_num_rows($resultado) == 0){
				echo "<p>Nenhum produto encontrado</p>";
			}
			else{
				while ($value = mysqli_fetch_array($resultado)){

			?>
				<div class="produto">
					<a href="#">
						<figure>
							<img src="img/products/<?= $value['categoria']; ?>/<?= mostraImagem($value['imagem']); ?>" alt="<?= $value['imagem']; ?>">
							<figcaption>
								<?= $value['nome']; ?>
								<span class="preco"><?= mostraPreco($value['preco']) ?></span>
							</figcaption>
						</figure>
					</a>
				</div>
				<?php						
				}
			}
			?>
			</div>
        </section>
	</main>

	<aside>
		<div class="col-7">
			<h3 class="col-8">Precisa de ajuda?</h3>
			<p>Use os contatos abaixo para contatar o suporte.</p>
			<p class="col-8">Telefones:</p>
			<ul>
				<li>(49) 9-8723-2141</li>
				<li>(49) 9-8523-2341</li>
				<li>(49) 9-8223-2641</li>
			</ul>
			<hr>
			<p class="col-8">Endereços eletrônicos (e-mails):</p>
			<ul>
				<li>fulanociclano123@gmail.com</li>
				<li>fulanociclano123@hotmail.com</li>
				<li>fulanociclano123@yahoo.com.br</li>
			</ul>
		</div>
	</aside>
	
<?php
include "includes/rodape.php";
?>