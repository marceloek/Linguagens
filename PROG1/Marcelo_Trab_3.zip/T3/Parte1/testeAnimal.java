import java.util.*;

public class testeAnimal{
	public static void main(String[] args){
		Animal Camelo = new Animal("Camelo", "Amarelo", "Terra", 150, 2, 4);
		Peixe Tubarao = new Peixe("Tubarão", "Cinzento", "Mar", 300, 1.5, 0, "Barbatanas e cauda");
		Mamifero UrsoCan = new Mamifero("Urso-do-canadá", "Vermelho", "Terra", 180, 0.5, 4, "Mel");
		Camelo.dados();
		Tubarao.dados();
		UrsoCan.dados();
	}
}