import java.util.*;

public class Mamifero extends Animal{
	private String Alimento;

	public Mamifero(String nom, String co, String ambient, int compriment, double velocidad, int pata, String aliment){
		super(nom, co, ambient, compriment, velocidad, pata);
		setAlimento(aliment);
	}

	public Mamifero(){

	}

	void setAlimento(String aliment){
		this.Alimento = aliment;
	}

	String getAlimento(){
		return this.Alimento;
	}

	@Override
	public void dados(){
		super.dados();
		System.out.println("Alimento: " +this.Alimento);
	} // imprimir na tela todos os dados
}