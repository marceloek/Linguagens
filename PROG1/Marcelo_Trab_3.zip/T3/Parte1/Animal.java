import java.util.*;

public class Animal{
	private String Nome;
	private int Comprimento;
	private String Cor;
	private String Ambiente;
	private double Velocidade;
	private int Patas;

	public Animal(String nom, String co, String ambient, int compriment, double velocidad, int pata){
		setNome(nom);
		setCor(co);
		setAmbiente(ambient);
		setComprimento(compriment);
		setVelocidade(velocidad);
		setPatas(pata);
	}

	public Animal(){

	}

	void setNome(String nom){
		this.Nome = nom;
	}

	void setComprimento(int compriment){
		this.Comprimento = compriment;
	}

	void setPatas(int pata){
		this.Patas = pata;
	}

	void setCor(String co){
		this.Cor = co;
	}

	void setAmbiente(String ambient){
		this.Ambiente = ambient;
	}

	void setVelocidade(double velocidad){
		this.Velocidade = velocidad;
	}

	public void dados(){
		System.out.println("------------------------------------");
		System.out.println("Nome: " +this.Nome);
		System.out.println("Comprimento: " +this.Comprimento+" cm");
		System.out.println("Patas: " +this.Patas);
		System.out.println("Cor: " +this.Cor);
		System.out.println("Ambiente: " +this.Ambiente);
		System.out.println("Velocidade: " +this.Velocidade+ " m/s");
	}
}