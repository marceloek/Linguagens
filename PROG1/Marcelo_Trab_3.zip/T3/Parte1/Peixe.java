import java.util.*;

public class Peixe extends Animal{
	private String Caracteristica;

	public Peixe(String nom, String co, String ambient, int compriment, double velocidad, int pata, String caracteristic){
		super(nom, co, ambient, compriment, velocidad, pata);
		setCaracteristica(caracteristic);
	}

	public Peixe(){

	}

	void setCaracteristica(String caracteristica){
		this.Caracteristica = caracteristica;
	}

	String getCaracteristica(){
		return this.Caracteristica;
	}

	@Override
	public void dados(){
		super.dados();
		System.out.println("Caracteristica: " +this.Caracteristica);
	}
}