import java.util.*;

public class Editora{
	private String nome;
	private String cnpj;

	public Editora(String nome, String cnpj){
		setnome(nome);
		setcnpj(cnpj);
	}

	void setnome(String nome){
		this.nome = nome;
	}

	void setcnpj(String cnpj){
		this.cnpj = cnpj;
	}
	public void Dados(){
		System.out.println("Nome da editora: "+this.nome);
		System.out.println("CNPJ da editora: "+this.cnpj);
	}

}