import java.util.*;

public class publicacaoSemanal extends Publicacao{
	private double taxaEntrega;

	public publicacaoSemanal(String nome, double preco){
		super(nome, preco);
		settaxaEntrega(preco);
	}

	void settaxaEntrega(double preco){
		this.taxaEntrega = preco *0.05*52;
	}

	public void calcularAnuidade(){
		double a = (taxaEntrega*1.75);
		super.calcularAnuidade(a);

	}

	public void calcularTaxaEntrega(double preco){
		settaxaEntrega(preco);
	}	

	@Override
	public void imprimirDados(){
		super.imprimirDados();
		System.out.println("Taxa de entrega: R$ "+this.taxaEntrega);
	}
} 
