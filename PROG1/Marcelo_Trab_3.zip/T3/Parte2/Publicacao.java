import java.util.*;

public class Publicacao{
	private String nome;
	private double precoExemplar;
	protected double valorAnuidade;
	Editora a = new Editora("Editora Três", "43209840000171");
	public Publicacao(String Nome, double preco){
		setnome(Nome);
		setprecoExemplar(preco);
	}

	void setnome(String Nome){
		this.nome = Nome;
	}

	String getnome(){
		return this.nome;
	}

	void setprecoExemplar(double preco){
		this.precoExemplar = preco;
	}

	void calcularAnuidade(double p){
		this.valorAnuidade = p *12;
	}

	public void imprimirDados(){
		System.out.println("Nome: "+this.nome);
		System.out.println("Preco do Exemplar: R$ "+this.precoExemplar);
		System.out.println("Valor da Anuidade: R$ "+this.valorAnuidade);
		a.Dados();
	}
}