import java.util.*;

public class Teste{
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		publicacaoSemanal pub = new publicacaoSemanal("IstoÉ", 16);
		pub.calcularAnuidade();
		pub.calcularTaxaEntrega(16);
		pub.imprimirDados();
	}
}